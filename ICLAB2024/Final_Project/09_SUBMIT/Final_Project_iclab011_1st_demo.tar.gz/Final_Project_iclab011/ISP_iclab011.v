module ISP(
    // Input Signals
    input clk,
    input rst_n,
    input in_valid,
    input [3:0] in_pic_no,
    input [1:0] in_mode,
    input [1:0] in_ratio_mode,
	
    // Output Signals
    output reg out_valid,
    output reg [7:0] out_data,
    
    // DRAM Signals
    // axi write address channel
    // src master
    output     [3:0]	awid_s_inf,//constant
    output reg [31:0]	awaddr_s_inf,
    output     [2:0]	awsize_s_inf,//constant
    output     [1:0]	awburst_s_inf,//constant
    output     [7:0]	awlen_s_inf,//constant
    output reg			awvalid_s_inf,
    // src slave
    input				awready_s_inf,
    // -----------------------------
	
    // axi write data channel 
    // src master
    output reg [127:0]	wdata_s_inf,
    output reg 			wlast_s_inf,
    output reg			wvalid_s_inf,
    // src slave
    input				wready_s_inf,
	
    // axi write response channel 
    // src slave
    input [3:0]			bid_s_inf,//constant
    input [1:0]			bresp_s_inf,//constant
    input				bvalid_s_inf,
    // src master 
    output reg 			bready_s_inf,
    // -----------------------------
	
    // axi read address channel 
    // src master
    output     [3:0]	arid_s_inf,//constant
    output reg [31:0]	araddr_s_inf,
    output     [7:0]	arlen_s_inf,//constant
    output     [2:0]	arsize_s_inf,//constant
    output     [1:0]	arburst_s_inf,//constant
    output reg			arvalid_s_inf,
    // src slave
    input				arready_s_inf,
    // -----------------------------
	
    // axi read data channel 
    // slave
    input [3:0]			rid_s_inf,//constant
    input [127:0]		rdata_s_inf,
    input [1:0]			rresp_s_inf,//constant
    input				rlast_s_inf,
    input				rvalid_s_inf,
    // master
    output reg			rready_s_inf
    
);
//==================================================================
// reg & wire & parameter & integer
//==================================================================
//inputs reg
reg [3:0] in_pic_no_reg;
reg [1:0] in_mode_reg;
reg [1:0] in_ratio_mode_reg;
//dram
reg [7:0] rdata_reg [0:15];
reg [7:0] wdata_reg [0:15];
reg rlast_reg;
reg rvalid_reg;
reg [5:0] dram_addr_cnt;
reg [5:0] addr_equal_63_flag;
reg [3:0] addr_equal_0_flag;
reg [1:0] dram_channel_cnt;
//FSM
reg [3:0] current_state, next_state;
parameter IDLE = 4'd0;
parameter READ_DRAM_ADDR = 4'd1;//read DRAM
parameter WRITE_DRAM_ADDR = 4'd2;//write DRAM
parameter HANDSHAKE = 4'd3;
parameter WAIT = 4'd4;
parameter WAIT2 = 4'd5;
parameter COMPUTE = 4'd6;
parameter OUT = 4'd7;
parameter OUT_OLD_VALUE = 4'd8;
parameter WAIT_ZERO_MAP = 4'd9;
parameter WAIT_ZERO_MAP2 = 4'd10;
//AUTO FOCUS
reg r_flag, g_flag, b_flag;
reg [7:0] gray_scale [0:15];
reg [5:0] map_counter;
reg [7:0] map [0:35];//6x6
reg contrast_enable_horizontal, contrast_enable_vertical, contrast_enable_div;
reg [2:0] contrast_counter_horizontal, contrast_counter_vertical;
reg contrast_enable_horizontal_2, contrast_enable_vertical_2, contrast_enable_div_2;
reg [2:0] contrast_counter_horizontal_2, contrast_counter_vertical_2;
reg [7:0] map2 [0:5][0:5];
reg find_abs_flag1, find_abs_flag2;
reg [7:0] find_abs;
reg contrast_enable_horizontal_3, contrast_enable_vertical_3, contrast_enable_div_3;
reg [2:0] contrast_counter_horizontal_3, contrast_counter_vertical_3;
reg [9:0] D0;//maximum is 253*(1*2)*2 = 1012
reg [12:0] D1;//maximum is 253*(3*4)*2 = 6072
reg [13:0] D2;//maximun is 253*(5*6)*2 = 15180
reg [11:0] div_in_9;
reg div_out_valid_9;
reg [8:0] div_out_9;
reg [1:0] compare;
//store auto focus
reg [1:0] contrast_map [0:15];
//AUTO EXPOSURE
reg [7:0] write_back_data [0:15];
reg [127:0] ratio_one_line;
reg [7:0] ratio [0:15];
reg [7:0] gray_scale_ratio [0:15];
reg average_final_reset_flag;
reg [7:0] average_1 [0:7];//8 bits, 8 elements
reg [8:0] average_2 [0:3];//9 bits, 4 elements
reg [9:0] average_3 [0:1];//10 bits, 2 elements
reg [10:0] average_4;//11 bits, 1 element
reg [18:0] average_final;//17 bits
//store auto exposure
reg if_all_zero;
reg [3:0] zero_map [0:15];//0 ~ 8
reg avg_map_valid [0:15];
reg [7:0] avg_map [0:15];
// Average of Min and Max in the Picture
reg [7:0] cmp_in [0:15];
reg [7:0] cmp_layer_1_max [0:7];
reg [7:0] cmp_layer_1_min [0:7];
reg [7:0] cmp_layer_2_max [0:3];
reg [7:0] cmp_layer_2_min [0:3];
reg [7:0] cmp_layer_3_max [0:1];
reg [7:0] cmp_layer_3_min [0:1];
reg [7:0] cmp_layer_4_max;
reg [7:0] cmp_layer_4_min;
reg [7:0] cmp_layer_5_max;
reg [7:0] cmp_layer_5_min;
reg [9:0] max_acc;
reg [9:0] min_acc;
reg div_in_valid_3_max;
reg [9:0] div_in_3_max;
reg div_in_valid_3_min;
reg [9:0] div_in_3_min;
reg div_out_valid_3_max;
reg [7:0] div_out_3_max;
reg div_out_valid_3_min;
reg [7:0] div_out_3_min;
reg [8:0] result;
reg result_map_valid [0:15];
reg [7:0] result_map [0:15];
//integers
integer i, j;
//==================================================================
// inputs registers
//==================================================================

//in_pic_no_reg, in_mode_reg, in_ratio_mode_reg
always@(posedge clk, negedge rst_n)
begin
	if(!rst_n)
	begin
		in_pic_no_reg <= 0;
		in_mode_reg <= 0;
		in_ratio_mode_reg <= 0;
	end
	else
	begin
		if(in_valid)
		begin
			in_pic_no_reg <= in_pic_no;
			in_mode_reg <= in_mode;
			in_ratio_mode_reg <= (in_mode == 1) ? (in_ratio_mode) : (2);
		end
		else
		begin
			in_pic_no_reg <= in_pic_no_reg;
			in_mode_reg <= in_mode_reg;
			in_ratio_mode_reg <= in_ratio_mode_reg;
		end
	end
end

//==================================================================
// DRAM
//==================================================================
//axi4 constants
// axi write address channel
assign awid_s_inf = 4'd0;
assign awsize_s_inf = 3'b100;
assign awburst_s_inf = 2'b01;
assign awlen_s_inf = 8'd191;
// axi write data channel
// axi write response channel
//assign bid_s_inf = 4'd0;			//same as awid_s_inf
//assign bresp_s_inf = 2'd00;
// axi read address channel
assign arid_s_inf = 4'd0; 			// fixed id to 0
assign arlen_s_inf = 8'd191;
assign arsize_s_inf = 3'b100;		// fixed size to 2^4 = 16 Bytes
assign arburst_s_inf = 2'd1;		// fixed mode to INCR mode 
// axi read data channel
//assign rid_s_inf = 4'd0;			//same as arid_s_inf
//assign rresp_s_inf = 2'd00;

// axi write address channel
always@(posedge clk, negedge rst_n)
begin
	if(!rst_n)
	begin
		awaddr_s_inf <= 0;
		awvalid_s_inf <= 0;
	end
	else
	begin
		case(current_state)
			WRITE_DRAM_ADDR:begin
								if(awready_s_inf)
								begin
									awaddr_s_inf <= 0;
									awvalid_s_inf <= 0;
								end
								else
								begin
									awaddr_s_inf <= 32'h10000 + (3*32*32)*in_pic_no_reg;
									awvalid_s_inf <= 1;
								end
							end
			default:		begin
								awaddr_s_inf <= 0;
								awvalid_s_inf <= 0;
							end
		endcase
	end
end

// axi write data channel
always@(posedge clk, negedge rst_n)
begin
	if(!rst_n)
	begin
		wdata_s_inf <= 0;
		wlast_s_inf <= 0;
		wvalid_s_inf <= 0;
	end
	else
	begin
		case(current_state)
			HANDSHAKE:
            begin
				wdata_s_inf <= ratio_one_line;
				wlast_s_inf <= 0;
				wvalid_s_inf <= (rvalid_s_inf) ? ((wready_s_inf) ? (0) : (1)) : (0);
			end
            WAIT:
            begin
                wdata_s_inf <= ratio_one_line;
				wlast_s_inf <= 0;
				wvalid_s_inf <= 0;
            end
			WAIT2:
            begin
                wdata_s_inf <= ratio_one_line;
				wlast_s_inf <= 0;
				wvalid_s_inf <= 0;
            end
            COMPUTE:
            begin
                wdata_s_inf <= ratio_one_line;
				wlast_s_inf <= (rlast_s_inf) ? (1) : (0);
				wvalid_s_inf <= (rvalid_s_inf) ? (1) : (0);
            end
			default:
            begin
                wdata_s_inf <= 0;
				wlast_s_inf <= 0;
				wvalid_s_inf <= 0;
            end
		endcase
	end
end

// axi write response channel
always@(posedge clk, negedge rst_n)
begin
	if(!rst_n)
		bready_s_inf <= 0;
	else if(rvalid_reg)
        bready_s_inf <= 1;
    else if(bvalid_s_inf)
        bready_s_inf <= 0;
end

// axi read address channel
always@(posedge clk, negedge rst_n)
begin
	if(!rst_n)
	begin
		araddr_s_inf <= 0;
		arvalid_s_inf <= 0;
	end
	else
	begin
		case(current_state)
			READ_DRAM_ADDR:	begin
								if(arready_s_inf)
								begin
									araddr_s_inf <= 0;
									arvalid_s_inf <= 0;
								end
								else
								begin
									araddr_s_inf <= 32'h10000 + (3*32*32)*in_pic_no_reg;
									arvalid_s_inf <= 1;
								end
							end
			default:		begin
								araddr_s_inf <= 0;
								arvalid_s_inf <= 0;
							end
		endcase
	end
end

// axi read data channel
always@(posedge clk, negedge rst_n)
begin
	if(!rst_n)
		rready_s_inf <= 0;
	else
		case(current_state)
            HANDSHAKE:      rready_s_inf <= (wready_s_inf) ? (1) : (0);
            WAIT:           rready_s_inf <= (wready_s_inf) ? (1) : (0);
			WAIT2:			rready_s_inf <= (in_mode_reg == 1) ? ((wready_s_inf) ? (1) : (0)) : ((rvalid_s_inf) ? (1) : (0));
			COMPUTE:        rready_s_inf <= (in_mode_reg == 1) ? ((wready_s_inf) ? (1) : (0)) : ((rvalid_s_inf) ? (1) : (0));
			default:		rready_s_inf <= 0;
		endcase
end

//rdata_reg
always@(posedge clk, negedge rst_n)
begin
    if(!rst_n)
    begin
        rdata_reg[ 0] <= 0;
        rdata_reg[ 1] <= 0;
        rdata_reg[ 2] <= 0;
        rdata_reg[ 3] <= 0;
        rdata_reg[ 4] <= 0;
        rdata_reg[ 5] <= 0;
        rdata_reg[ 6] <= 0;
        rdata_reg[ 7] <= 0;
        rdata_reg[ 8] <= 0;
        rdata_reg[ 9] <= 0;
        rdata_reg[10] <= 0;
        rdata_reg[11] <= 0;
        rdata_reg[12] <= 0;
        rdata_reg[13] <= 0;
        rdata_reg[14] <= 0;
        rdata_reg[15] <= 0;
    end
    else if(rvalid_s_inf || rvalid_reg)
    begin
        rdata_reg[ 0] <= rdata_s_inf[127:120];
        rdata_reg[ 1] <= rdata_s_inf[119:112];
        rdata_reg[ 2] <= rdata_s_inf[111:104];
        rdata_reg[ 3] <= rdata_s_inf[103: 96];
        rdata_reg[ 4] <= rdata_s_inf[ 95: 88];
        rdata_reg[ 5] <= rdata_s_inf[ 87: 80];
        rdata_reg[ 6] <= rdata_s_inf[ 79: 72];
        rdata_reg[ 7] <= rdata_s_inf[ 71: 64];
        rdata_reg[ 8] <= rdata_s_inf[ 63: 56];
        rdata_reg[ 9] <= rdata_s_inf[ 55: 48];
        rdata_reg[10] <= rdata_s_inf[ 47: 40];
        rdata_reg[11] <= rdata_s_inf[ 39: 32];
        rdata_reg[12] <= rdata_s_inf[ 31: 24];
        rdata_reg[13] <= rdata_s_inf[ 23: 16];
        rdata_reg[14] <= rdata_s_inf[ 15:  8];
        rdata_reg[15] <= rdata_s_inf[  7:  0];
    end
end

//reg [7:0] wdata_reg [0:15];
always@(*)
begin
    wdata_reg[ 0] = wdata_s_inf[127:120];
    wdata_reg[ 1] = wdata_s_inf[119:112];
    wdata_reg[ 2] = wdata_s_inf[111:104];
    wdata_reg[ 3] = wdata_s_inf[103: 96];
    wdata_reg[ 4] = wdata_s_inf[ 95: 88];
    wdata_reg[ 5] = wdata_s_inf[ 87: 80];
    wdata_reg[ 6] = wdata_s_inf[ 79: 72];
    wdata_reg[ 7] = wdata_s_inf[ 71: 64];
    wdata_reg[ 8] = wdata_s_inf[ 63: 56];
    wdata_reg[ 9] = wdata_s_inf[ 55: 48];
    wdata_reg[10] = wdata_s_inf[ 47: 40];
    wdata_reg[11] = wdata_s_inf[ 39: 32];
    wdata_reg[12] = wdata_s_inf[ 31: 24];
    wdata_reg[13] = wdata_s_inf[ 23: 16];
    wdata_reg[14] = wdata_s_inf[ 15:  8];
    wdata_reg[15] = wdata_s_inf[  7:  0];
end

//rlast_reg
always@(posedge clk, negedge rst_n)
begin
    if(!rst_n)
        rlast_reg <= 0;
    else
        rlast_reg <= rlast_s_inf;
end

//rvalid_reg
always@(posedge clk, negedge rst_n)
begin
    if(!rst_n)
        rvalid_reg <= 0;
    else
        rvalid_reg <= rvalid_s_inf;
end

//reg [5:0] dram_addr_cnt;
always@(posedge clk, negedge rst_n)
begin
    if(!rst_n)
        dram_addr_cnt <= 0;
    else if(current_state == IDLE)
        dram_addr_cnt <= 0;
    else if(rready_s_inf && current_state == COMPUTE)
        dram_addr_cnt <= dram_addr_cnt + 1;
end

//reg [4:0] addr_equal_63_flag;
always@(posedge clk, negedge rst_n)
begin
    if(!rst_n)
        addr_equal_63_flag <= 5'b0;
    else
    begin
        addr_equal_63_flag[0] <= (dram_addr_cnt == 63) ? (1) : (0);
        addr_equal_63_flag[1] <= addr_equal_63_flag[0];
        addr_equal_63_flag[2] <= addr_equal_63_flag[1];
        addr_equal_63_flag[3] <= addr_equal_63_flag[2];
        addr_equal_63_flag[4] <= addr_equal_63_flag[3];
		addr_equal_63_flag[5] <= addr_equal_63_flag[4];
    end
end

//reg [3:0] addr_equal_0_flag;
always@(posedge clk, negedge rst_n)
begin
    if(!rst_n)
        addr_equal_0_flag <= 4'b0;
    else
    begin
        addr_equal_0_flag[0] <= (dram_addr_cnt == 0) ? (1) : (0);
        addr_equal_0_flag[1] <= addr_equal_0_flag[0];
        addr_equal_0_flag[2] <= addr_equal_0_flag[1];
        addr_equal_0_flag[3] <= addr_equal_0_flag[2];
    end
end

//reg [1:0] dram_channel_cnt;
always@(posedge clk, negedge rst_n)
begin
    if(!rst_n)
        dram_channel_cnt <= 0;
    else if(current_state == IDLE)
        dram_channel_cnt <= 0;
    else if(dram_addr_cnt == 63)
        dram_channel_cnt <= dram_channel_cnt + 1;
end

//==================================================================
// DESIGN
//==================================================================
//FSM
//current_state
always@(posedge clk, negedge rst_n)
begin
    if(!rst_n)
        current_state <= IDLE;
    else
        current_state <= next_state;
end

//next_state
always@(*)
begin
    case(current_state)
        IDLE:
        if(in_valid)
            case(in_mode)
                0:          next_state = (contrast_map[in_pic_no] != 3) ? (OUT_OLD_VALUE) : (READ_DRAM_ADDR);//auto focus
                1:          next_state = WAIT_ZERO_MAP;//auto exposure
                2:          next_state = (result_map_valid[in_pic_no]) ? (OUT_OLD_VALUE) : (READ_DRAM_ADDR);//Average of Min and Max in the Picture
                default:    next_state = IDLE;
            endcase
        else
                            next_state = IDLE;
        //next_state = (in_valid) ? (READ_DRAM_ADDR) : (IDLE);
        READ_DRAM_ADDR:     next_state = (arready_s_inf) ? ((in_mode_reg == 1) ? (WRITE_DRAM_ADDR) : (WAIT2)) : (READ_DRAM_ADDR);
        WRITE_DRAM_ADDR:    next_state = (awready_s_inf) ? (HANDSHAKE) : (WRITE_DRAM_ADDR);
        HANDSHAKE:          next_state = (wvalid_s_inf && wready_s_inf) ? (WAIT) : (HANDSHAKE);
        WAIT:               next_state = COMPUTE;
		WAIT2:				next_state = (rvalid_reg) ? (COMPUTE) : (WAIT2);
        COMPUTE:
        case(in_mode_reg)
            0:              next_state = (div_out_valid_9) ? (OUT) : (COMPUTE);
            1:              next_state = (div_out_valid_9) ? (OUT) : (COMPUTE);//addr_equal_63_flag[4] && dram_channel_cnt == 3
            2:              next_state = (div_out_valid_9) ? (OUT) : (COMPUTE);//div_out_valid_3_max && div_out_valid_3_min
            default:        next_state = IDLE;
        endcase
        OUT:                next_state = IDLE;
        WAIT_ZERO_MAP:      next_state = WAIT_ZERO_MAP2;//auto exposure
        WAIT_ZERO_MAP2:     next_state = (zero_map[in_pic_no_reg] == 8) ? (OUT_OLD_VALUE) : ((avg_map_valid[in_pic_no_reg] && in_ratio_mode_reg == 2) ? (OUT_OLD_VALUE) : (READ_DRAM_ADDR));//auto exposure
        OUT_OLD_VALUE:      next_state = IDLE;
        default:            next_state = IDLE;
    endcase
end

//==================================================================
// AUTO FOCUS
//==================================================================

//reg r_flag, g_flag, b_flag;
always@(*)
begin
	/*
    if(in_mode_reg == 1)
    begin
        r_flag = (dram_addr_cnt > 25 && dram_addr_cnt < 38 && dram_channel_cnt == 0) ? (1) : (0);//R, 26 ~ 37
        g_flag = (dram_addr_cnt > 25 && dram_addr_cnt < 38 && dram_channel_cnt == 1) ? (1) : (0);//G, 90 ~ 101
        b_flag = (dram_addr_cnt > 25 && dram_addr_cnt < 38 && dram_channel_cnt == 2) ? (1) : (0);//B, 154 ~ 165
    end
    else
    begin
        r_flag = (dram_addr_cnt > 25+1 && dram_addr_cnt < 38+1 && dram_channel_cnt == 0) ? (1) : (0);//R, 26 ~ 37
        g_flag = (dram_addr_cnt > 25+1 && dram_addr_cnt < 38+1 && dram_channel_cnt == 1) ? (1) : (0);//G, 90 ~ 101
        b_flag = (dram_addr_cnt > 25+1 && dram_addr_cnt < 38+1 && dram_channel_cnt == 2) ? (1) : (0);//B, 154 ~ 165
    end*/
	r_flag = (dram_addr_cnt > 25 && dram_addr_cnt < 38 && dram_channel_cnt == 0) ? (1) : (0);//R, 26 ~ 37
    g_flag = (dram_addr_cnt > 25 && dram_addr_cnt < 38 && dram_channel_cnt == 1) ? (1) : (0);//G, 90 ~ 101
    b_flag = (dram_addr_cnt > 25 && dram_addr_cnt < 38 && dram_channel_cnt == 2) ? (1) : (0);//B, 154 ~ 165
end

//reg [7:0] gray_scale [0:15];
always@(*)
begin
    if(in_mode_reg == 1)
        if(r_flag)
            for(i=0;i<16;i=i+1)
                gray_scale[i] = wdata_reg[i] >> 2;
        else if(g_flag)
            for(i=0;i<16;i=i+1)
                gray_scale[i] = wdata_reg[i] >> 1;
        else if(b_flag)
            for(i=0;i<16;i=i+1)
                gray_scale[i] = wdata_reg[i] >> 2;
        else
            for(i=0;i<16;i=i+1)
                gray_scale[i] = 0;
    else
        
        if(r_flag)
            for(i=0;i<16;i=i+1)
                gray_scale[i] = rdata_reg[i] >> 2;
        else if(g_flag)
            for(i=0;i<16;i=i+1)
                gray_scale[i] = rdata_reg[i] >> 1;
        else if(b_flag)
            for(i=0;i<16;i=i+1)
                gray_scale[i] = rdata_reg[i] >> 2;
        else
            for(i=0;i<16;i=i+1)
                gray_scale[i] = 0;
end

//reg [5:0] map_counter;
always@(posedge clk, negedge rst_n)
begin
    if(!rst_n)
        map_counter <= 0;
    else if(r_flag || g_flag || b_flag)
        map_counter <= map_counter + 1;
    else
        map_counter <= 0;
end

//reg [7:0] map [0:35];//6x6
always@(posedge clk, negedge rst_n)
begin
    if(!rst_n)
        for(i=0;i<36;i=i+1)
            map[i] <= 0;
    else if(current_state == IDLE)
        for(i=0;i<36;i=i+1)
            map[i] <= 0;
    else if(r_flag || g_flag || b_flag)
        case(map_counter)
            0:
            begin
                map[ 0] <= map[ 0] + gray_scale[ 2];
                map[ 1] <= map[ 1] + gray_scale[ 1];
                map[ 2] <= map[ 2] + gray_scale[ 0];
            end
            1:
            begin
                map[ 3] <= map[ 3] + gray_scale[15];
                map[ 4] <= map[ 4] + gray_scale[14];
                map[ 5] <= map[ 5] + gray_scale[13];
            end
            2:
            begin
                map[ 6] <= map[ 6] + gray_scale[ 2];
                map[ 7] <= map[ 7] + gray_scale[ 1];
                map[ 8] <= map[ 8] + gray_scale[ 0];
            end
            3:
            begin
                map[ 9] <= map[ 9] + gray_scale[15];
                map[10] <= map[10] + gray_scale[14];
                map[11] <= map[11] + gray_scale[13];
            end
            4:
            begin
                map[12] <= map[12] + gray_scale[ 2];
                map[13] <= map[13] + gray_scale[ 1];
                map[14] <= map[14] + gray_scale[ 0];
            end
            5:
            begin
                map[15] <= map[15] + gray_scale[15];
                map[16] <= map[16] + gray_scale[14];
                map[17] <= map[17] + gray_scale[13];
            end
            6:
            begin
                map[18] <= map[18] + gray_scale[ 2];
                map[19] <= map[19] + gray_scale[ 1];
                map[20] <= map[20] + gray_scale[ 0];
            end
            7:
            begin
                map[21] <= map[21] + gray_scale[15];
                map[22] <= map[22] + gray_scale[14];
                map[23] <= map[23] + gray_scale[13];
            end
            8:
            begin
                map[24] <= map[24] + gray_scale[ 2];
                map[25] <= map[25] + gray_scale[ 1];
                map[26] <= map[26] + gray_scale[ 0];
            end
            9:
            begin
                map[27] <= map[27] + gray_scale[15];
                map[28] <= map[28] + gray_scale[14];
                map[29] <= map[29] + gray_scale[13];
            end
            10:
            begin
                map[30] <= map[30] + gray_scale[ 2];
                map[31] <= map[31] + gray_scale[ 1];
                map[32] <= map[32] + gray_scale[ 0];
            end
            11:
            begin
                map[33] <= map[33] + gray_scale[15];
                map[34] <= map[34] + gray_scale[14];
                map[35] <= map[35] + gray_scale[13];
            end
        endcase
end

//reg contrast_enable_horizontal;
always@(posedge clk, negedge rst_n)
begin
    if(!rst_n)
        contrast_enable_horizontal <= 0;
    else if(b_flag && map_counter == 11)
        contrast_enable_horizontal <= 1;
    else if(contrast_enable_horizontal && contrast_counter_horizontal == 4 && contrast_counter_vertical == 5)
        contrast_enable_horizontal <= 0;
end

//reg contrast_enable_vertical;
always@(posedge clk, negedge rst_n)
begin
    if(!rst_n)
        contrast_enable_vertical <= 0;
    else if(contrast_enable_horizontal && contrast_counter_horizontal == 4 && contrast_counter_vertical == 5)
        contrast_enable_vertical <= 1;
    else if(contrast_enable_vertical && contrast_counter_horizontal == 4 && contrast_counter_vertical == 5)
        contrast_enable_vertical <= 0;
end

//contrast_enable_div
always@(posedge clk, negedge rst_n)
begin
    if(!rst_n)
        contrast_enable_div <= 0;
    else
        contrast_enable_div <= (contrast_enable_vertical && contrast_counter_horizontal == 4 && contrast_counter_vertical == 5) ? (1) : (0);
end

//contrast_counter_horizontal
always@(posedge clk, negedge rst_n)
begin
    if(!rst_n)
        contrast_counter_horizontal <= 0;
    else
        if(contrast_enable_horizontal)
            contrast_counter_horizontal <= (contrast_counter_horizontal == 4) ? (0) : (contrast_counter_horizontal + 1);
        else if(contrast_enable_vertical)
            contrast_counter_horizontal <= (contrast_counter_horizontal == 4) ? (0) : (contrast_counter_horizontal + 1);
        else
            contrast_counter_horizontal <=  0;
end

//contrast_counter_vertical
always@(posedge clk, negedge rst_n)
begin
    if(!rst_n)
        contrast_counter_vertical <= 0;
    else
        if(contrast_enable_horizontal)
            contrast_counter_vertical <= (contrast_counter_horizontal == 4) ? ((contrast_counter_vertical == 5) ? (0) : (contrast_counter_vertical + 1)) : (contrast_counter_vertical);
        else if(contrast_enable_vertical)
            contrast_counter_vertical <= (contrast_counter_horizontal == 4) ? ((contrast_counter_vertical == 5) ? (0) : (contrast_counter_vertical + 1)) : (contrast_counter_vertical);
        else
            contrast_counter_vertical <=  0;
end

////////////////////////////////////////////////////////////////////layer 2

//reg contrast_enable_horizontal_2, contrast_enable_vertical_2, contrast_enable_div_2;
always@(posedge clk, negedge rst_n)
begin
    if(!rst_n)
    begin
        contrast_enable_horizontal_2 <= 0;
        contrast_enable_vertical_2 <= 0;
        contrast_enable_div_2 <= 0;
    end
    else
    begin
        contrast_enable_horizontal_2 <= contrast_enable_horizontal;
        contrast_enable_vertical_2 <= contrast_enable_vertical;
        contrast_enable_div_2 <= contrast_enable_div;
    end
end

//reg [5:0] contrast_counter_horizontal_2, contrast_counter_vertical_2;
always@(posedge clk, negedge rst_n)
begin
    if(!rst_n)
    begin
        contrast_counter_horizontal_2 <= 0;
        contrast_counter_vertical_2 <= 0;
    end
    else
    begin
        contrast_counter_horizontal_2 <= contrast_counter_horizontal;
        contrast_counter_vertical_2 <= contrast_counter_vertical;
    end
end

//reg [7:0] map2 [0:5][0:5];
always@(*)
begin
    for(i=0;i<6;i=i+1)
        for(j=0;j<6;j=j+1)
            map2[i][j] = map[i+6*j];
end

//reg find_abs_flag1, find_abs_flag2;
always@(posedge clk, negedge rst_n)
begin
    if(!rst_n)
    begin
        find_abs_flag1 <= 0;
        find_abs_flag2 <= 0;
    end
    else
    begin
        find_abs_flag1 <= (map2[contrast_counter_horizontal][contrast_counter_vertical] > map2[contrast_counter_horizontal + 1][contrast_counter_vertical]) ? (1) : (0);
        find_abs_flag2 <= (map2[contrast_counter_vertical][contrast_counter_horizontal] > map2[contrast_counter_vertical][contrast_counter_horizontal + 1]) ? (1) : (0);
    end
end

//reg [7:0] find_abs;
always@(posedge clk, negedge rst_n)
begin
    if(!rst_n)
        find_abs <= 0;
	else if(contrast_enable_horizontal_2)
		if(find_abs_flag1)
			find_abs <= map2[contrast_counter_horizontal_2][contrast_counter_vertical_2] - map2[contrast_counter_horizontal_2 + 1][contrast_counter_vertical_2];
		else
			find_abs <= map2[contrast_counter_horizontal_2 + 1][contrast_counter_vertical_2] - map2[contrast_counter_horizontal_2][contrast_counter_vertical_2];
	else if(contrast_enable_vertical_2)
		if(find_abs_flag2)
			find_abs <= map2[contrast_counter_vertical_2][contrast_counter_horizontal_2] - map2[contrast_counter_vertical_2][contrast_counter_horizontal_2 + 1];
		else
			find_abs <= map2[contrast_counter_vertical_2][contrast_counter_horizontal_2 + 1] - map2[contrast_counter_vertical_2][contrast_counter_horizontal_2];
	else
		find_abs <= 0;
end

////////////////////////////////////////////////////////////////////layer 3

//reg contrast_enable_horizontal_3, contrast_enable_vertical_3, contrast_enable_div_3;
always@(posedge clk, negedge rst_n)
begin
    if(!rst_n)
    begin
        contrast_enable_horizontal_3 <= 0;
        contrast_enable_vertical_3 <= 0;
        contrast_enable_div_3 <= 0;
    end
    else
    begin
        contrast_enable_horizontal_3 <= contrast_enable_horizontal_2;
        contrast_enable_vertical_3 <= contrast_enable_vertical_2;
        contrast_enable_div_3 <= contrast_enable_div_2;
    end
end

//reg [5:0] contrast_counter_horizontal_3, contrast_counter_vertical_3;
always@(posedge clk, negedge rst_n)
begin
    if(!rst_n)
    begin
        contrast_counter_horizontal_3 <= 0;
        contrast_counter_vertical_3 <= 0;
    end
    else
    begin
        contrast_counter_horizontal_3 <= contrast_counter_horizontal_2;
        contrast_counter_vertical_3 <= contrast_counter_vertical_2;
    end
end

//reg [9:0] D0;//maximum is 255*(1*2)*2 = 1020
always@(posedge clk, negedge rst_n)
begin
    if(!rst_n)
        D0 <= 0;
	else if(current_state == IDLE)
		D0 <= 0;
	else if(contrast_enable_horizontal_3 || contrast_enable_vertical_3)
		case({contrast_counter_horizontal_3, contrast_counter_vertical_3})//contrast_counter_horizontal add 1
			{3'd2,3'd2}:    D0 <= D0 + find_abs;
            {3'd2,3'd3}:    D0 <= D0 + find_abs;
			default:        D0 <= D0;
        endcase
	else if(contrast_enable_div_3)
		D0 <= D0 >> 2;// D0 / 4
    else
		D0 <= D0;
end

//reg [12:0] D1;//maximum is 255*(3*4)*2 = 6120
always@(posedge clk, negedge rst_n)
begin
    if(!rst_n)
        D1 <= 0;
	else if(current_state == IDLE)
        D1 <= 0;
	else if(contrast_enable_horizontal_3 || contrast_enable_vertical_3)
		case({contrast_counter_horizontal_3, contrast_counter_vertical_3})//contrast_counter_horizontal add 1
            {3'd1,3'd1}:    D1 <= D1 + find_abs;
            {3'd2,3'd1}:    D1 <= D1 + find_abs;
            {3'd3,3'd1}:    D1 <= D1 + find_abs;
            {3'd1,3'd2}:    D1 <= D1 + find_abs;
            {3'd2,3'd2}:    D1 <= D1 + find_abs;
            {3'd3,3'd2}:    D1 <= D1 + find_abs;
            {3'd1,3'd3}:    D1 <= D1 + find_abs;
            {3'd2,3'd3}:    D1 <= D1 + find_abs;
            {3'd3,3'd3}:    D1 <= D1 + find_abs;
            {3'd1,3'd4}:    D1 <= D1 + find_abs;
            {3'd2,3'd4}:    D1 <= D1 + find_abs;
            {3'd3,3'd4}:    D1 <= D1 + find_abs;
			default:        D1 <= D1;
		endcase
	else if(contrast_enable_div_3)
        D1 <= D1 >> 4;// D1 / 16
    else
        D1 <= D1;
end

//reg [13:0] D2;//maximun is 255*(5*6)*2 = 15300
always@(posedge clk, negedge rst_n)
begin
    if(!rst_n)
        D2 <= 0;
	else if(current_state == IDLE)
		D2 <= 0;
	else if(contrast_enable_horizontal_3 || contrast_enable_vertical_3)
        D2 <= D2 + find_abs;
    else if(div_out_valid_9)
        D2 <= div_out_9;//D2 <= D2 / 36 
	else
        D2 <= D2;
end

//reg [11:0] div_in_9;
always@(*)
begin
	div_in_9 = (D2 >> 2);
end

nine_divider div1(	.clk(clk), 
					.rst_n(rst_n), 
					.div_in_valid(contrast_enable_div_3), 
					.div_in(div_in_9), 
					.div_out_valid(div_out_valid_9), 
					.div_out(div_out_9));

//reg [1:0] compare;
always@(*)
begin
    if(D0 >= D1)
		if(D0 >= D2)
			compare = 0;
		else
			if(D1 >= D2)
				compare = 1;
			else
				compare = 2;
	else
		if(D1 >= D2)
			compare = 1;
		else
			if(D0 >= D2)
				compare = 0;
			else
				compare = 2;
end

//==================================================================
// STORE CONTRAST
//==================================================================

//reg [1:0] contrast_map [0:15];
always@(posedge clk, negedge rst_n)
begin
	if(!rst_n)
		for(i=0;i<16;i=i+1)
			contrast_map[i] <= 3;//0,1,2 are contrast value of pictures before, 3 means no data
	else
		if(current_state == OUT)
            contrast_map[in_pic_no_reg] <= compare;
        else if(zero_map[in_pic_no_reg] == 8)
            contrast_map[in_pic_no_reg] <= 0;
		else
			contrast_map[in_pic_no_reg] <= contrast_map[in_pic_no_reg];
end

//==================================================================
// AUTO EXPOSURE
//==================================================================

//reg [7:0] write_back_data [0:15];
always@(*)
begin
	case(in_ratio_mode_reg)
		0:			begin//right shift 2
						write_back_data[ 0] = rdata_s_inf[127:120]>>2;
						write_back_data[ 1] = rdata_s_inf[119:112]>>2;
						write_back_data[ 2] = rdata_s_inf[111:104]>>2;
						write_back_data[ 3] = rdata_s_inf[103: 96]>>2;
						write_back_data[ 4] = rdata_s_inf[ 95: 88]>>2;
						write_back_data[ 5] = rdata_s_inf[ 87: 80]>>2;
						write_back_data[ 6] = rdata_s_inf[ 79: 72]>>2;
						write_back_data[ 7] = rdata_s_inf[ 71: 64]>>2;
						write_back_data[ 8] = rdata_s_inf[ 63: 56]>>2;
						write_back_data[ 9] = rdata_s_inf[ 55: 48]>>2;
						write_back_data[10] = rdata_s_inf[ 47: 40]>>2;
						write_back_data[11] = rdata_s_inf[ 39: 32]>>2;
						write_back_data[12] = rdata_s_inf[ 31: 24]>>2;
						write_back_data[13] = rdata_s_inf[ 23: 16]>>2;
						write_back_data[14] = rdata_s_inf[ 15:  8]>>2;
						write_back_data[15] = rdata_s_inf[  7:  0]>>2;
					end
		1:			begin//right shift 1
						write_back_data[ 0] = rdata_s_inf[127:120]>>1;
						write_back_data[ 1] = rdata_s_inf[119:112]>>1;
						write_back_data[ 2] = rdata_s_inf[111:104]>>1;
						write_back_data[ 3] = rdata_s_inf[103: 96]>>1;
						write_back_data[ 4] = rdata_s_inf[ 95: 88]>>1;
						write_back_data[ 5] = rdata_s_inf[ 87: 80]>>1;
						write_back_data[ 6] = rdata_s_inf[ 79: 72]>>1;
						write_back_data[ 7] = rdata_s_inf[ 71: 64]>>1;
						write_back_data[ 8] = rdata_s_inf[ 63: 56]>>1;
						write_back_data[ 9] = rdata_s_inf[ 55: 48]>>1;
						write_back_data[10] = rdata_s_inf[ 47: 40]>>1;
						write_back_data[11] = rdata_s_inf[ 39: 32]>>1;
						write_back_data[12] = rdata_s_inf[ 31: 24]>>1;
						write_back_data[13] = rdata_s_inf[ 23: 16]>>1;
						write_back_data[14] = rdata_s_inf[ 15:  8]>>1;
						write_back_data[15] = rdata_s_inf[  7:  0]>>1;
					end
		2:			begin//dont change
						write_back_data[ 0] = rdata_s_inf[127:120];
						write_back_data[ 1] = rdata_s_inf[119:112];
						write_back_data[ 2] = rdata_s_inf[111:104];
						write_back_data[ 3] = rdata_s_inf[103: 96];
						write_back_data[ 4] = rdata_s_inf[ 95: 88];
						write_back_data[ 5] = rdata_s_inf[ 87: 80];
						write_back_data[ 6] = rdata_s_inf[ 79: 72];
						write_back_data[ 7] = rdata_s_inf[ 71: 64];
						write_back_data[ 8] = rdata_s_inf[ 63: 56];
						write_back_data[ 9] = rdata_s_inf[ 55: 48];
						write_back_data[10] = rdata_s_inf[ 47: 40];
						write_back_data[11] = rdata_s_inf[ 39: 32];
						write_back_data[12] = rdata_s_inf[ 31: 24];
						write_back_data[13] = rdata_s_inf[ 23: 16];
						write_back_data[14] = rdata_s_inf[ 15:  8];
						write_back_data[15] = rdata_s_inf[  7:  0];
					end
		3:			begin//left shift 1 and dont exceed 255
						write_back_data[ 0] = (rdata_s_inf[127]) ? (8'd255) : (rdata_s_inf[127:120]<<1);
						write_back_data[ 1] = (rdata_s_inf[119]) ? (8'd255) : (rdata_s_inf[119:112]<<1);
						write_back_data[ 2] = (rdata_s_inf[111]) ? (8'd255) : (rdata_s_inf[111:104]<<1);
						write_back_data[ 3] = (rdata_s_inf[103]) ? (8'd255) : (rdata_s_inf[103: 96]<<1);
						write_back_data[ 4] = (rdata_s_inf[ 95]) ? (8'd255) : (rdata_s_inf[ 95: 88]<<1);
						write_back_data[ 5] = (rdata_s_inf[ 87]) ? (8'd255) : (rdata_s_inf[ 87: 80]<<1);
						write_back_data[ 6] = (rdata_s_inf[ 79]) ? (8'd255) : (rdata_s_inf[ 79: 72]<<1);
						write_back_data[ 7] = (rdata_s_inf[ 71]) ? (8'd255) : (rdata_s_inf[ 71: 64]<<1);
						write_back_data[ 8] = (rdata_s_inf[ 63]) ? (8'd255) : (rdata_s_inf[ 63: 56]<<1);
						write_back_data[ 9] = (rdata_s_inf[ 55]) ? (8'd255) : (rdata_s_inf[ 55: 48]<<1);
						write_back_data[10] = (rdata_s_inf[ 47]) ? (8'd255) : (rdata_s_inf[ 47: 40]<<1);
						write_back_data[11] = (rdata_s_inf[ 39]) ? (8'd255) : (rdata_s_inf[ 39: 32]<<1);
						write_back_data[12] = (rdata_s_inf[ 31]) ? (8'd255) : (rdata_s_inf[ 31: 24]<<1);
						write_back_data[13] = (rdata_s_inf[ 23]) ? (8'd255) : (rdata_s_inf[ 23: 16]<<1);
						write_back_data[14] = (rdata_s_inf[ 15]) ? (8'd255) : (rdata_s_inf[ 15:  8]<<1);
						write_back_data[15] = (rdata_s_inf[  7]) ? (8'd255) : (rdata_s_inf[  7:  0]<<1);
					end
		default:	begin
						write_back_data[ 0] = rdata_s_inf[127:120];
						write_back_data[ 1] = rdata_s_inf[119:112];
						write_back_data[ 2] = rdata_s_inf[111:104];
						write_back_data[ 3] = rdata_s_inf[103: 96];
						write_back_data[ 4] = rdata_s_inf[ 95: 88];
						write_back_data[ 5] = rdata_s_inf[ 87: 80];
						write_back_data[ 6] = rdata_s_inf[ 79: 72];
						write_back_data[ 7] = rdata_s_inf[ 71: 64];
						write_back_data[ 8] = rdata_s_inf[ 63: 56];
						write_back_data[ 9] = rdata_s_inf[ 55: 48];
						write_back_data[10] = rdata_s_inf[ 47: 40];
						write_back_data[11] = rdata_s_inf[ 39: 32];
						write_back_data[12] = rdata_s_inf[ 31: 24];
						write_back_data[13] = rdata_s_inf[ 23: 16];
						write_back_data[14] = rdata_s_inf[ 15:  8];
						write_back_data[15] = rdata_s_inf[  7:  0];
					end
	endcase
end

//ratio_one_line
always@(*)
begin
	ratio_one_line = {	write_back_data[0], 
						write_back_data[1], 
						write_back_data[2], 
						write_back_data[3], 
						write_back_data[4], 
						write_back_data[5], 
						write_back_data[6], 
						write_back_data[7], 
						write_back_data[8], 
						write_back_data[9], 
						write_back_data[10], 
						write_back_data[11], 
						write_back_data[12], 
						write_back_data[13], 
						write_back_data[14], 
						write_back_data[15]	};
end

//reg [7:0] ratio [0:15];
always@(*)
begin
	case(in_ratio_mode_reg)
		0://right shift 2
            for(i=0;i<16;i=i+1)
                ratio[i] = rdata_reg[i] >> 2;
		1://right shift 1
            for(i=0;i<16;i=i+1)
                ratio[i] = rdata_reg[i] >> 1;
		2://dont change
            for(i=0;i<16;i=i+1)
                ratio[i] = rdata_reg[i];
		3://left shift 1 and dont exceed 255
            for(i=0;i<16;i=i+1)
                ratio[i] = (rdata_reg[i][7]) ? (8'd255) : (rdata_reg[i] << 1);
		default://dont change
            for(i=0;i<16;i=i+1)
                ratio[i] = rdata_reg[i];
	endcase
end

//reg [7:0] gray_scale_ratio [0:15];
always@(*)
begin
    case(dram_channel_cnt)
        0://right shift 2
            for(i=0;i<16;i=i+1)
                gray_scale_ratio[i] = ratio[i] >> 2;
        1://right shift 1
            for(i=0;i<16;i=i+1)
                gray_scale_ratio[i] = ratio[i] >> 1;
        2://right shift 2
            for(i=0;i<16;i=i+1)
                gray_scale_ratio[i] = ratio[i] >> 2;
        default:
            for(i=0;i<16;i=i+1)
                gray_scale_ratio[i] = 0;
    endcase
end

//reg average_final_reset_flag;
always@(*)
begin
    average_final_reset_flag = (dram_addr_cnt == 4 && dram_channel_cnt == 0) ? (1) : (0);
end

//reg [7:0] average_1 [0:7];//8 bits, 8 elements
//reg [8:0] average_2 [0:3];//9 bits, 4 elements
//reg [9:0] average_3 [0:1];//10 bits, 2 elements
//reg [10:0] average_4;//11 bits, 1 element
//reg [18:0] average_final;//17 bits
always@(posedge clk, negedge rst_n)
begin
    if(!rst_n)
    begin
        for(i=0;i<8;i=i+1)
			average_1[i] <= 0;
        for(i=0;i<4;i=i+1)
            average_2[i] <= 0;
        for(i=0;i<2;i=i+1)
            average_3[i] <= 0;
        average_4 <= 0;
        average_final <= 0;
    end
    else if(current_state == IDLE)
    begin
        for(i=0;i<8;i=i+1)
			average_1[i] <= 0;
        for(i=0;i<4;i=i+1)
            average_2[i] <= 0;
        for(i=0;i<2;i=i+1)
            average_3[i] <= 0;
        average_4 <= 0;
        average_final <= 0;
    end
    else
    begin
        for(i=0;i<8;i=i+1)
            average_1[i] <= gray_scale_ratio[2*i] + gray_scale_ratio[2*i+1];
        for(i=0;i<4;i=i+1)
            average_2[i] <= average_1[2*i] + average_1[2*i+1];
        for(i=0;i<2;i=i+1)
            average_3[i] <= average_2[2*i] + average_2[2*i+1];
        average_4 <= average_3[0] + average_3[1];
        average_final <= (average_final_reset_flag) ? (average_4) : (average_final + average_4);
    end
end

//==================================================================
// STORE ZERO MAP
//==================================================================

//reg [3:0] zero_map [0:15];
always@(posedge clk, negedge rst_n)
begin
    if(!rst_n)
        for(i=0;i<16;i=i+1)
            zero_map[i] <= 0;
    else
        if(current_state == WAIT_ZERO_MAP)//auto exposure
            if(zero_map[in_pic_no_reg] == 8)
                zero_map[in_pic_no_reg] <= zero_map[in_pic_no_reg];
            else
                case(in_ratio_mode_reg)
                    0:          zero_map[in_pic_no_reg] <= (zero_map[in_pic_no_reg] < 7) ? (zero_map[in_pic_no_reg] + 2) : (8);
                    1:          zero_map[in_pic_no_reg] <= (zero_map[in_pic_no_reg] < 8) ? (zero_map[in_pic_no_reg] + 1) : (8);
                    2:          zero_map[in_pic_no_reg] <= zero_map[in_pic_no_reg];
                    3:          zero_map[in_pic_no_reg] <= (zero_map[in_pic_no_reg] > 0) ? (zero_map[in_pic_no_reg] - 1) : (0);
                    default:    zero_map[in_pic_no_reg] <= zero_map[in_pic_no_reg];
                endcase
        else
            zero_map[in_pic_no_reg] <= zero_map[in_pic_no_reg];
end

//==================================================================
// STORE AVG MAP
//==================================================================

//reg avg_map_valid [0:15];
always@(posedge clk, negedge rst_n)
begin
    if(!rst_n)
        for(i=0;i<16;i=i+1)
            avg_map_valid[i] <= 0;
    else
        if(current_state == OUT)
            if(in_ratio_mode_reg == 2)
                avg_map_valid[in_pic_no_reg] <= 1;
            else
                avg_map_valid[in_pic_no_reg] <= 0;
        else
            avg_map_valid[in_pic_no_reg] <= avg_map_valid[in_pic_no_reg];
end

//reg [7:0] avg_map [0:15];
always@(posedge clk, negedge rst_n)
begin
    if(!rst_n)
        for(i=0;i<16;i=i+1)
            avg_map[i] <= 0;
    else
        if(current_state == OUT)
            avg_map[in_pic_no_reg] <= average_final >> 10;
        else
            avg_map[in_pic_no_reg] <= avg_map[in_pic_no_reg];
end

//==================================================================
// Average of Min and Max in the Picture
//==================================================================

//reg [7:0] cmp_in [0:15];
always@(*)
begin
    if(in_mode_reg == 1)//auto exposure
        for(i=0;i<16;i=i+1)
            cmp_in[i] = wdata_reg[i];
    else
        for(i=0;i<16;i=i+1)
            cmp_in[i] = rdata_reg[i];
end

//reg [7:0] cmp_layer_1_max [0:7];
//reg [7:0] cmp_layer_1_min [0:7];
//reg [7:0] cmp_layer_2_max [0:3];
//reg [7:0] cmp_layer_2_min [0:3];
//reg [7:0] cmp_layer_3_max [0:1];
//reg [7:0] cmp_layer_3_min [0:1];
//reg [7:0] cmp_layer_4_max;
//reg [7:0] cmp_layer_4_min;
//reg [7:0] cmp_layer_5_max;
//reg [7:0] cmp_layer_5_min;
//reg [9:0] max_acc;
//reg [9:0] min_acc;
always@(posedge clk, negedge rst_n)
begin
    if(!rst_n)
    begin
        for(i=0;i<8;i=i+1)
            cmp_layer_1_max[i] <= 0;
        for(i=0;i<8;i=i+1)
            cmp_layer_1_min[i] <= 0;
        for(i=0;i<4;i=i+1)
            cmp_layer_2_max[i] <= 0;
        for(i=0;i<4;i=i+1)
            cmp_layer_2_min[i] <= 0;
        for(i=0;i<2;i=i+1)
            cmp_layer_3_max[i] <= 0;
        for(i=0;i<2;i=i+1)
            cmp_layer_3_min[i] <= 0;
        cmp_layer_4_max <= 0;
        cmp_layer_4_min <= 0;
        cmp_layer_5_max <= 0;
        cmp_layer_5_min <= 255;
        max_acc <= 0;
        min_acc <= 0;
    end
    else if(current_state == IDLE)
    begin
        for(i=0;i<8;i=i+1)
            cmp_layer_1_max[i] <= 0;
        for(i=0;i<8;i=i+1)
            cmp_layer_1_min[i] <= 0;
        for(i=0;i<4;i=i+1)
            cmp_layer_2_max[i] <= 0;
        for(i=0;i<4;i=i+1)
            cmp_layer_2_min[i] <= 0;
        for(i=0;i<2;i=i+1)
            cmp_layer_3_max[i] <= 0;
        for(i=0;i<2;i=i+1)
            cmp_layer_3_min[i] <= 0;
        cmp_layer_4_max <= 0;
        cmp_layer_4_min <= 0;
        cmp_layer_5_max <= 0;
        cmp_layer_5_min <= 255;
        max_acc <= 0;
        min_acc <= 0;
    end
    else
    begin
        for(i=0;i<8;i=i+1)
            cmp_layer_1_max[i] <= (cmp_in[2*i] > cmp_in[2*i+1]) ? (cmp_in[2*i]) : (cmp_in[2*i+1]);
        for(i=0;i<8;i=i+1)
            cmp_layer_1_min[i] <= (cmp_in[2*i] > cmp_in[2*i+1]) ? (cmp_in[2*i+1]) : (cmp_in[2*i]);
        for(i=0;i<4;i=i+1)
            cmp_layer_2_max[i] <= (cmp_layer_1_max[2*i] > cmp_layer_1_max[2*i+1]) ? (cmp_layer_1_max[2*i]) : (cmp_layer_1_max[2*i+1]);
        for(i=0;i<4;i=i+1)
            cmp_layer_2_min[i] <= (cmp_layer_1_min[2*i] > cmp_layer_1_min[2*i+1]) ? (cmp_layer_1_min[2*i+1]) : (cmp_layer_1_min[2*i]);
        for(i=0;i<2;i=i+1)
            cmp_layer_3_max[i] <= (cmp_layer_2_max[2*i] > cmp_layer_2_max[2*i+1]) ? (cmp_layer_2_max[2*i]) : (cmp_layer_2_max[2*i+1]);
        for(i=0;i<2;i=i+1)
            cmp_layer_3_min[i] <= (cmp_layer_2_min[2*i] > cmp_layer_2_min[2*i+1]) ? (cmp_layer_2_min[2*i+1]) : (cmp_layer_2_min[2*i]);
        cmp_layer_4_max <= (cmp_layer_3_max[1] > cmp_layer_3_max[0]) ? (cmp_layer_3_max[1]) : (cmp_layer_3_max[0]);
        cmp_layer_4_min <= (cmp_layer_3_min[1] > cmp_layer_3_min[0]) ? (cmp_layer_3_min[0]) : (cmp_layer_3_min[1]);
        cmp_layer_5_max <= (addr_equal_0_flag[3]) ? (cmp_layer_4_max) : ((cmp_layer_5_max > cmp_layer_4_max) ? (cmp_layer_5_max) : (cmp_layer_4_max));
        cmp_layer_5_min <= (addr_equal_0_flag[3]) ? (cmp_layer_4_min) : ((cmp_layer_5_min > cmp_layer_4_min) ? (cmp_layer_4_min) : (cmp_layer_5_min));
        max_acc <= (current_state == IDLE) ? (0) : ((addr_equal_63_flag[4]) ? (max_acc + cmp_layer_5_max) : (max_acc));
        min_acc <= (current_state == IDLE) ? (0) : ((addr_equal_63_flag[4]) ? (min_acc + cmp_layer_5_min) : (min_acc));
    end
end

//reg div_in_valid_3_max;
//reg [9:0] div_in_3_max;
//reg div_in_valid_3_min;
//reg [9:0] div_in_3_min;
always@(posedge clk, negedge rst_n)
begin
    if(!rst_n)
    begin
        div_in_valid_3_max <= 0;
        div_in_3_max <= 0;
        div_in_valid_3_min <= 0;
        div_in_3_min <= 0;
    end
    else if(addr_equal_63_flag[5] && dram_channel_cnt == 3)
    begin
        div_in_valid_3_max <= 1;
        div_in_3_max <= max_acc;
        div_in_valid_3_min <= 1;
        div_in_3_min <= min_acc;
    end
    else
    begin
        div_in_valid_3_max <= 0;
        div_in_3_max <= 0;
        div_in_valid_3_min <= 0;
        div_in_3_min <= 0;
    end
end

//reg div_out_valid_3_max;
//reg [7:0] div_out_3_max;
//reg div_out_valid_3_min;
//reg [7:0] div_out_3_min;
three_divider div2(	.clk(clk), 
					.rst_n(rst_n), 
					.div_in_valid(div_in_valid_3_max), 
					.div_in(div_in_3_max), 
					.div_out_valid(div_out_valid_3_max), 
					.div_out(div_out_3_max));
three_divider div3(	.clk(clk), 
					.rst_n(rst_n), 
					.div_in_valid(div_in_valid_3_min), 
					.div_in(div_in_3_min), 
					.div_out_valid(div_out_valid_3_min), 
					.div_out(div_out_3_min));

//reg [8:0] result;
always@(posedge clk, negedge rst_n)
begin
    if(!rst_n)
        result <= 0;
    else
        result <= (div_out_valid_3_max && div_out_valid_3_min) ? ((div_out_3_max + div_out_3_min) >> 1) : (result);
end

//==================================================================
// STORE RESULT MAP
//==================================================================

//reg result_map_valid [0:15];
always@(posedge clk, negedge rst_n)
begin
    if(!rst_n)
        for(i=0;i<16;i=i+1)
            result_map_valid[i] <= 0;
    else
        if(current_state == OUT)
            result_map_valid[in_pic_no_reg] <= 1;
        else if(current_state == OUT_OLD_VALUE && in_mode_reg == 1)
            result_map_valid[in_pic_no_reg] <= 1;
        else
            result_map_valid[in_pic_no_reg] <= result_map_valid[in_pic_no_reg];
end

//reg [7:0] result_map [0:15];
always@(posedge clk, negedge rst_n)
begin
    if(!rst_n)
        for(i=0;i<16;i=i+1)
            result_map[i] <= 0;
    else
        if(current_state == OUT)
            result_map[in_pic_no_reg] <= result;
        else if(zero_map[in_pic_no_reg] == 8)
            result_map[in_pic_no_reg] <= 0;
        else
            result_map[in_pic_no_reg] <= result_map[in_pic_no_reg];
end

//==================================================================
// OUT
//==================================================================

//out_valid, out_data
always@(posedge clk, negedge rst_n)
begin
	if(!rst_n)
	begin
		out_valid <= 0;
		out_data <= 0;
	end
	else
	begin
		case(current_state)
			OUT:
            begin
                case(in_mode_reg)
                    0://auto focus
                    begin
                        out_valid <= 1;
                        out_data <= compare;
                    end
                    1://auto exposure
                    begin
                        out_valid <= 1;
                        out_data <= average_final >> 10;
                    end
                    2://Average of Min and Max in the Picture
                    begin
                        out_valid <= 1;
                        out_data <= result;
                    end
                    default:
                    begin
                        out_valid <= 0;
                        out_data <= 0;
                    end
                endcase
			end
            OUT_OLD_VALUE:
            begin
                case(in_mode_reg)
                    0://auto focus
                    begin
                        out_valid <= 1;
                        out_data <= contrast_map[in_pic_no_reg];
                    end
                    1://auto exposure
                    begin
                        out_valid <= 1;
                        out_data <= (zero_map[in_pic_no_reg] == 8) ? (0) : (avg_map[in_pic_no_reg]);
                    end
                    2://Average of Min and Max in the Picture
                    begin
                        out_valid <= 1;
                        out_data <= result_map[in_pic_no_reg];
                    end
                    default:
                    begin
                        out_valid <= 0;
                        out_data <= 0;
                    end
                endcase
            end
			default:
            begin
				out_valid <= 0;
				out_data <= 0;
			end
		endcase
	end
end

endmodule















module nine_divider (
    input clk,
    input rst_n,
    input div_in_valid,
    input  [11:0] div_in,
    output div_out_valid,
    output [8:0] div_out
);

reg [11:0] quotient;
reg [12:0] div_counter;
reg [3:0] index;
reg busy;

// accumulation
wire [12:0] div_sub_counter;
wire [11:0] next_quotient;
wire [12:0] next_div_counter;

assign div_sub_counter = div_counter - 'd9;
assign {next_div_counter, next_quotient} = (div_counter >= 'd9) ? {div_sub_counter, quotient, 1'b1} : ({div_counter, quotient} << 1);

// output
assign div_out_valid = index == 'd11;
assign div_out = next_quotient;

always @(posedge clk, negedge rst_n)
begin
    if (!rst_n)
        busy <= 1'b0;
    else if(div_in_valid)
        busy <= 1'b1;
    else if (div_out_valid)
        busy <= 1'b0;
end

always @(posedge clk, negedge rst_n)
begin
    if (!rst_n)
        index <= 'd0;
    else if (div_out_valid | div_in_valid)
        index <= 'd0;
    else if (busy)
        index <= index + 'd1;
end

always@(posedge clk, negedge rst_n)
begin
    if (!rst_n)
    begin
        div_counter <= 0;
        quotient <= 0;
    end
    else if (div_out_valid)
    begin
        div_counter <= 0;
        quotient <= 0;
    end 
    else if (div_in_valid)
    begin
        {div_counter, quotient} <= {12'd0, div_in, 1'b0};
    end 
    else if (busy)
    begin
        {div_counter, quotient} <= {next_div_counter, next_quotient};
    end
end

endmodule








module three_divider (
    input clk,
    input rst_n,
    input div_in_valid,
    input  [9:0] div_in,
    output div_out_valid,
    output [7:0] div_out
);

reg [8:0] quotient;
reg [2:0] acc;
reg [3:0] index;
reg busy;

// accumulation
wire [2:0] sub_acc;
wire [8:0] next_quotient;
wire [2:0] next_acc;

assign sub_acc = acc - 'd3;
assign {next_acc, next_quotient} = (acc >= 'd3) ? {sub_acc, quotient, 1'b1} : ({acc, quotient} << 1);

// output
assign div_out_valid = index == 'd8;
assign div_out = next_quotient;

always @(posedge clk, negedge rst_n)
begin
    if (!rst_n)
        busy <= 1'b0;
    else if(div_in_valid)
        busy <= 1'b1;
    else if (div_out_valid)
        busy <= 1'b0;
end

always @(posedge clk, negedge rst_n)
begin
    if (!rst_n)
        index <= 'd0;
    else if (div_out_valid | div_in_valid)
        index <= 'd0;
    else if (busy)
        index <= index + 'd1;
end

always@(posedge clk, negedge rst_n)
begin
    if(!rst_n)
    begin
        acc <= 0;
        quotient <= 0;
    end
    else if(div_in_valid)
    begin
        {acc, quotient} <= {1'd0, div_in, 1'b0};
    end 
    else if(busy)
    begin
        {acc, quotient} <= {next_acc, next_quotient};
    end
    else if(div_out_valid)
    begin
        acc <= 0;
        quotient <= 0;
    end
end

endmodule